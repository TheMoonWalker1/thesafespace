#!/bin/sh

# Assumes your program is called index.js
exec node index.js
